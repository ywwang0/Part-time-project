%%Coursework of <name> <knumber>, Feb 2021%%
% rename this file to k12345678.m for submission, using your k number
%%%%%%%%%%%%%
%% initialization

clear; close all; clc; format longg;

load 'USPS_dataset9296.mat' X t; % loads 9296 handwritten 16x16 images X dim(X)=[9296x256] and the lables t in [0:9] dim(t)=[9298x1]
[Ntot,D] =      size(X);         % Ntot = number of total dataset samples. D =256=input dimension

% Anonymous functions as inlines
show_vec_as_image16x16 =    @(row_vec)      imshow(-(reshape(row_vec,16,16)).');    % shows the image of a row vector with 256 elements. For matching purposes, a negation and rotation are needed.
sigmoid =                   @(x)            1./(1+exp(-x));                         % overwrites the existing sigmoid, in order to avoid the toolbox
LSsolver =                  @(Xmat,tvec)    ( Xmat.' * Xmat ) \ Xmat.' * tvec;      % Least Square solver

PLOT_DATASET =  0;      % For visualization. Familiarise yourself by running with 1. When submiting the file, set back to 0
if PLOT_DATASET
    figure(8); sgtitle('First 24 samples and labels from USPS data set');
    for n=1:4*6
        subplot(4,6,n);
        show_vec_as_image16x16(X(n,:));
        title(['t_{',num2str(n),'}=',num2str(t(n)),'   x_{',num2str(n),'}=']);
    end
end

% cod here initialization code that manipulations the data sets

%%Section 1

% code here, supporting dim(theta)=10

figure(1); hold on; title('Section 1: ERM regression, quadratic loss');
% plot code here

% supporting code here that help to calculate and displaying without a ";" the two variables
% traininglossLS_257    % Training   loss when dim(theta)=257.
% validationlossLS_257  % Validation loss when dim(theta)=257.

% code here, supporting dim(theta)=10
% traininglossLS_10    % Training   loss when dim(theta)=10.
% validationlossLS_10  % Validation loss when dim(theta)=10.

% plot code here (using the "hold on", it will overlay)

% complete the insight:
display('The predictions with the longer and shorter feature vectors are different because ...')

%%Section 2

% supporting code
figure(2); hold on; title('Section 2: Logistic Regression');
% plot code

display('I have chosen S=0.5 and gamma=200, as they were the ones that minimized the validation loss in a smaller number of 6 iterations, although some other pairs have lower training loss but higher validation loss.');

%%Section 3

% sime code here, and replace the three <???> in the plots:
figure(3); sgtitle('Section 3: PCA most significant Eigen vectors');
subplot(2,2,1); show_vec_as_image16x16(<???>); title('Most significant');
subplot(2,2,2); show_vec_as_image16x16(<???>); title('Second significant');
subplot(2,2,3); show_vec_as_image16x16(<???>); title('Third significant');

figure(4); sgtitle('Section 3: Estimating using PCA, M = number of significant components');

% some code here, and replace the three <???> in the plots:
subplot(2,2,1); show_vec_as_image16x16(<???>);   title('First training set image');
subplot(2,2,2); show_vec_as_image16x16(<???>);   title('Reconstracting using M=1 most significant components');
subplot(2,2,3); show_vec_as_image16x16(<???>);   title('Reconstracting using M=2');
subplot(2,2,4); show_vec_as_image16x16(<???>);   title('Reconstracting using M=3');

figure(5); hold on; title('Significant PCA components over all training set. o=0, x=1');
% plot here, using plot3

%%Section 4

% supporting code here

figure(6); hold on; title('Section 4: Logistic Regression');
% plot code

% complete the insight:
display('Comparing with the solution in Section 2, I conclude that...');


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A list of functions you may want to familiarise yourself with. Check the help for full details.

% + - * / ^ 						% basic operators
% : 								% array indexing
% * 								% matrix mult
% .* .^ ./							% element-wise operators
% x.' (or x' when x is surly real)	% transpose
% [A;B] [A,B] 						% aray concatenation
% A(row,:) 							% array slicing
% round()
% exp()
% log()
% svd()
% max()
% sqrt()
% sum()
% ones()
% zeros()
% length()
% randn()
% randperm()
% figure()
% plot()
% plot3()
% title()
% legend()
% xlabel(),ylabel(),zlabel()
% hold on;
% grid minor;
