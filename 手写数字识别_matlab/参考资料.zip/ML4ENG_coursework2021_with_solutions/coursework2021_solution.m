%%Coursework of <name> <knumber>, Feb 2021%%
% rename this file to k12345678.m for submission, using your k number
%%%%%%%%%%%%%
%% initialization

clear; close all; clc; format longg;

load 'USPS_dataset9296.mat' X t; % loads 9296 handwritten 16x16 images X dim(X)=[9296x256] and the lables t in [0:9] dim(t)=[9298x1]
[Ntot,D] =      size(X);         % Ntot = number of total dataset samples. D =256=input dimension

% Anonymous functions as inlines
show_vec_as_image16x16 =    @(row_vec)      imshow(-(reshape(row_vec,16,16)).');    % shows the image of a row vector with 256 elements. For matching purposes, a negation and rotation are needed.
sigmoid =                   @(x)            1./(1+exp(-x));                         % overwrites the existing sigmoid, in order to avoid the toolbox
LSsolver =                  @(Xmat,tvec)    ( Xmat.' * Xmat ) \ Xmat.' * tvec;      % Least Square solver

PLOT_DATASET =  0;      % For visualization. Familiarise yourself by running with 1. When submiting the file, set back to 0
if PLOT_DATASET
    figure(8); sgtitle('First 24 samples and labels from USPS data set');
    for n=1:4*6
        subplot(4,6,n);
        show_vec_as_image16x16(X(n,:));
        title(['t_{',num2str(n),'}=',num2str(t(n)),'   x_{',num2str(n),'}=']);
    end
end

ind_t0 =        (t==0);                             % indices of the total data set, labelled t=0
ind_t1 =        (t==1);                             % indices of the total data set, labelled t=1

N0tot =         sum(ind_t0);                        % total number of points labelled t=0;
N1tot =         sum(ind_t1);                        % total number of points labelled t=1;
N0 =            round(0.7*N0tot);                   % training size for t=0
N1 =            round(0.7*N1tot);                   % training size for t=1
N =             N0 + N1;                            % total training set size
N0va =          N0tot - N0;                         % validation  set size for t=0
N1va =          N1tot - N1;                         % validation  set size for t=1
Nva =           N0va + N1va;                        % total test set size

X0tot =         X    ( ind_t0        , : );         % stacking all x's with t=0
X1tot =         X    ( ind_t1        , : );         % stacking all x's with t=1
X0 =            X0tot(    1 : N0     , : );         % forming the training   x's labelled t=0 by slicing the first 70% data points
X1 =            X1tot(    1 : N1     , : );         % "           training   "            t=1 "              first 70% "
X0va =          X0tot( N0+1 : N0tot  , : );         % "           validation "            t=0 "              last  30% "
X1va =          X1tot( N1+1 : N1tot  , : );         % "           validation "            t=1 "              last  30% "

X_D =           [ X0              ; X1            ];% the x for the training   set. dim=[N   x 256]
t_D =           [ zeros([N0,1])   ; ones([N1,1])  ];% the t for the training   set. dim=[N   x 256]

X_D_va =        [ X0va            ; X1va          ];% the x for the validation set. dim=[Nva x 256]
t_D_va =        [ zeros([N0va,1]) ; ones([N1va,1])];% the t for the validation set. dim=[Nva x 256]

if PLOT_DATASET % more visualizations
    figure(9);  sgtitle('The first 24 training inputs labelled as t=0');
    for n=1:4*6
        subplot(4,6,n);
        show_vec_as_image16x16(X_D(n,:));
        title(['t_{',num2str(n),'}=0   x_{',num2str(n),'}=']);
    end
    figure(10);  sgtitle('The first 24 training inputs labelled as t=1');
    for n=1:4*6
        subplot(4,6,n);
        show_vec_as_image16x16(X_D(N0+n,:));
        title(['t_{',num2str(N0+n),'}=1   x_{',num2str(N0+n),'}=']);
    end
 end

%%Section 1

X_D_Sec1 =                  [ones(N  ,1) , X_D   ]; % adding the freedom for bias for the training set
X_D_Sec1_va =               [ones(Nva,1) , X_D_va]; % adding the freedom for bias for the test     set

% dim(theta)=257
theta_ERM_257 =             LSsolver(X_D_Sec1,t_D);  % ERM with dim(theta)=257. ERM is LS for quadratic loss, given the training data
t_hat_D_Sec1_257 =          X_D_Sec1    * theta_ERM_257; % training

figure(1); hold on; title('Section 1: ERM regression, quadratic loss');
plot( 1:N , t_hat_D_Sec1_257 , 'g' , 'DisplayName','predictor dim=257');
plot( 1:N , t_D              , 'k.', 'DisplayName','true data points');
xlabel('training set index $n$','Interpreter','latex'); ylabel('digit [0/1]');
legend('Location','southeast');

t_hat_D_Sec1_va_257 =       X_D_Sec1_va * theta_ERM_257; % predictions over the test data set, uses test the same trained theta
traininglossLS_257 =        1/N     * sum((t_D    - t_hat_D_Sec1_257   ).^2)
validationlossLS_257 =      1/Nva   * sum((t_D_va - t_hat_D_Sec1_va_257).^2)

% dim(theta)=10
theta_ERM_10 =              LSsolver(X_D_Sec1(:,1:10),t_D);  % ERM with dim(theta)=10. ERM is LS for quadratic loss, given the training data
t_hat_D_Sec1_10 =           X_D_Sec1   (:,1:10) * theta_ERM_10; % training
t_hat_D_Sec1_va_10 =        X_D_Sec1_va(:,1:10) * theta_ERM_10; % predictions over the test data set, uses test the same trained theta
traininglossLS_10 =         1/N     * sum((t_D    - t_hat_D_Sec1_10     ).^2)
validationlossLS_10 =       1/Nva   * sum((t_D_va - t_hat_D_Sec1_va_10  ).^2)

plot( 1:N , t_hat_D_Sec1_10   , 'r', 'DisplayName' ,'predictor dim=10' );

display('The predictions with the longer and shorter feature vectors are different because the longer is able to weight all 256 pixels (seeing the whole picture), whereas the short has to predict using only the first nine, which are not rich enough to express differences between digit 0 and digit 1.')

%%Section 2

Svec =                      [50,200,800];       % Options for batches sizes
gamma_vec =                 [0.5,1,2];   % Options for learning rate
MaxIter =                   50; % maximal number of Logistic regression iterations

trainingloss_Sec2 =         NaN(MaxIter,length(Svec),length(gamma_vec));
validationloss_Sec2 =       NaN(MaxIter,length(Svec),length(gamma_vec));

for Sind=1:length(Svec)
    S =                         Svec(Sind);
    for gamma_ind=1:length(gamma_vec)
        gamma =                 gamma_vec(gamma_ind);
        % init theta
        theta_Sec2 =              [1/sqrt(D+1)*randn(D+1,1),NaN(D+1,MaxIter)];
        for ii=1:MaxIter-1
            batch_ind =         randperm(N,S);
            total_sum =         0;
            for n=1:S
                u_of_x_n =      ( X_D_Sec1( batch_ind(n) , : ) ).';
                t_n =           t_D       ( batch_ind(n) );
                sigmoid_n =     sigmoid( (theta_Sec2(:,ii)).' * u_of_x_n );
                total_sum =     total_sum + ( sigmoid_n - t_n ) * u_of_x_n; % scalar x vector
            end
            theta_Sec2(:,ii+1) =  theta_Sec2(:,ii) - gamma/S * total_sum;
            % evaluate logits
            logit_lr_D =        X_D_Sec1    * theta_Sec2(:,ii) ; % logits of the training set
            logit_lr_D_va =     X_D_Sec1_va * theta_Sec2(:,ii) ; % logits of the test     set
            % evaluate training and validation losses. In logistic regression, we evaluate the log loss
            trainingloss_Sec2(ii,Sind,gamma_ind) =    1/N     * sum( log( 1 + exp( -(2*t_D   -1) .* logit_lr_D    )));
            validationloss_Sec2(ii,Sind,gamma_ind) =  1/Nva   * sum( log( 1 + exp( -(2*t_D_va-1) .* logit_lr_D_va )));
        end
    end
end

figure(2); hold on; title('Section 2: Logistic Regression');
colors =  {'b','r','g','m','c','k','y'};
markers = {'o','s','d','p'};
for Sind=1:length(Svec)
    S = Svec(Sind);
    for gamma_ind=1:length(gamma_vec)
        gamma =                 gamma_vec(gamma_ind);
        plot((1:MaxIter).',trainingloss_Sec2  (:,Sind,gamma_ind)   ,[colors{gamma_ind},markers{Sind},'--'] ,'LineWidth',1,'DisplayName',['\gamma=',num2str(gamma),' S=',num2str(S),' training'  ]);
        plot((1:MaxIter).',validationloss_Sec2(:,Sind,gamma_ind)   ,[colors{gamma_ind},markers{Sind},'-']  ,'LineWidth',2.5,'DisplayName',['\gamma=',num2str(gamma),' S=',num2str(S),' validation' ]);
    end
end
xlabel('iterations'); ylabel('Log-Loss'); grid minor;
legend('Location','eastoutside'); set(gca,'YLim',[0 0.1]);

display('I have chosen S=0.5 and gamma=200, as they were the ones that minimized the validation loss in a smaller number of 6 iterations, although some other pairs have lower training loss but higher validation loss.');



% 
% %%Section 3
% 
% mu_hat =                    1/N * sum(X_D,2); % empirical_average
% [ U, Sigma ,  ~ ] =         svd(1/N * (X_D-mu_hat).' * (X_D-mu_hat));
% W =                         U(:,1:3); % in svd(), the columns of U which are the first eigenvectors correspond to the largest eigen value
% figure(3); sgtitle('Section 3: PCA most significant Eigen vectors');
% subplot(2,2,1); show_vec_as_image16x16((W(:,1)/max(abs(W(:,1)))).'); title('Most significant');
% subplot(2,2,2); show_vec_as_image16x16((W(:,2)/max(abs(W(:,2)))).'); title('Second significant');
% subplot(2,2,3); show_vec_as_image16x16((W(:,3)/max(abs(W(:,3)))).'); title('Third significant');
% 
% %
% figure(4); sgtitle('Section 3: Estimating using PCA, M = number of significant components');
% x_1 =            (X_D(1,:)).';
% z_1_1 =          (W(:,1)).'* x_1; % contribution of the 1st component w_1 to estimate x_1
% z_1_2 =          (W(:,2)).'* x_1; % contribution of the 2nd component w_2 to estimate x_1
% z_1_3 =          (W(:,3)).'* x_1; % contribution of the 3rd component w_3 to estimate x_1
% x_1_est_most1 =  z_1_1 * W(:,1);
% x_1_est_most2 =  z_1_2 * W(:,2) + x_1_est_most1;
% x_1_est_most3 =  z_1_3 * W(:,3) + x_1_est_most2;
% 
% subplot(2,2,1); show_vec_as_image16x16(x_1);             title('First training set image');
% subplot(2,2,2); show_vec_as_image16x16(x_1_est_most1);   title('Reconstracting using M=1 most significant components');
% subplot(2,2,3); show_vec_as_image16x16(x_1_est_most2);   title('Reconstracting using M=2');
% subplot(2,2,4); show_vec_as_image16x16(x_1_est_most3);   title('Reconstracting using M=3');
% 
% figure(5); hold on; title('Significant PCA components over all training set. o=0, x=1');
% for n=1:N
%     x_n =               (X_D(n,:)).';
%     z_n =               (W(:,1:3)).' * x_n; % row vector, dim=[3 x 1]
%     markers ={'bo','rx'};
%     plot3(z_n(1),z_n(2),z_n(3),markers{1+t_D(n)}); 
% end
% xlabel('z_1');ylabel('z_2');zlabel('z_3');
% 
% %%Section 4
% D_Sec4 =                    2;
% X_D_Sec4 =                  NaN(N,3);
% for n=1:N
%     x_n =                   (X_D(n,:)).';
%     z_n =                   (W(:,1:2)).' * x_n; % row vector, dim=[2x256 x 256x1]=[2 x 1]
%     X_D_Sec4(n,:) =         [1,z_n(1),z_n(2)];
% end
% 
% trainingloss_Sec4 =         NaN(MaxIter,length(Svec),length(gamma_vec));
% 
% for Sind=1:length(Svec)
%     S =                         Svec(Sind);
%     for gamma_ind=1:length(gamma_vec)
%         gamma =                 gamma_vec(gamma_ind);
%         % init theta
%         theta_Sec4 =            [1/sqrt(D_Sec4+1)*randn(D_Sec4+1,1),NaN(D_Sec4+1,MaxIter)];
%         for ii=1:MaxIter-1
%             batch_ind =         randperm(N,S);
%             total_sum =         0;
%             for n=1:S
%                 u_of_x_n =      ( X_D_Sec4( batch_ind(n) , : ) ).';
%                 t_n =           t_D       ( batch_ind(n) );
%                 sigmoid_n =     sigmoid( (theta_Sec4(:,ii)).' * u_of_x_n );
%                 total_sum =     total_sum + ( sigmoid_n - t_n ) * u_of_x_n; % scalar x vector
%             end
%             theta_Sec4(:,ii+1) =  theta_Sec4(:,ii) - gamma/S * total_sum;
%             % evaluate logits
%             logit_lr_D =        X_D_Sec4     * theta_Sec4(:,ii) ; % logits of the training set
%             % evaluate training loss. In logistic regression, we evaluate the log loss
%             trainingloss_Sec4(ii,Sind,gamma_ind) =    1/N     * sum( log( 1 + exp( -(2*t_D   -1) .* logit_lr_D    )));
%         end
%     end
% end
% 
% figure(6); hold on; title('Section 4: Logistic Regression');
% colors =  {'b','r','g','m','c','k','y'};
% markers = {'o','s','d','p'};
% for Sind=1:length(Svec)
%     S = Svec(Sind);
%     for gamma_ind=1:length(gamma_vec)
%         gamma =                 gamma_vec(gamma_ind);
%         plot((1:MaxIter).',trainingloss_Sec2  (:,Sind,gamma_ind)   ,[colors{gamma_ind},markers{Sind},'-'] ,'LineWidth',1,'DisplayName',['\gamma=',num2str(gamma),' S=',num2str(S),' training'  ]);
%     end
% end
% xlabel('iterations'); ylabel('Log-Loss'); grid minor;
% legend('Location','eastoutside'); set(gca,'YLim',[0 0.1]);
% 
% display('Comparing with the solution in Section 2, I conclude that since the training loss is very similar, the two significant components capture most of the features and well represents the 256 dimensional input space');
